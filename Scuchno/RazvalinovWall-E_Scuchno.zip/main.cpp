#include <iostream>
#include <map>
#include <set>
#include <string>
#include <io.h>
#include <fcntl.h>
#include <windows.h>


#include "data.hpp" // предполагаем, что здесь описаны scu::Data, scu::Stage, Event, Choice и Trait
using namespace scu;

// Функция для вывода трейтов
void print_trait(const Trait& trait) {
	std::wcout << L"Трейт: " << trait.name << L" (" << trait.description << L") Значение: " << trait.value << std::endl;
}

// Функция для вывода всех трейтов
void print_traits(const std::map<std::string, Trait>& traits) {
	for (const auto& trait : traits) {
		print_trait(trait.second);  // Печать каждого трейта
	}
}

// Функция для вывода событий
void print_event(const Event& event) {
	std::wcout << L"Событие: " << event.description << std::endl;

	for (const auto& [choice_key, choice] : event.choices) {
		std::wcout << L"  Выбор: " << choice.description << std::endl;
	}
}

// Функция для вывода стадии
void print_stage(const Stage& stage) {
	std::wcout << L"Стадия: " << stage.name << L" (" << stage.description << L")\n";
	for (const auto& event : stage.events) {  // Теперь правильное обращение
		print_event(event.second); // Печать события
	}
}

// Функция для вывода всех данных
void print_all_data() {
	print_traits(Data::traits); // Печать всех трейтов
	//  вывод стадий, если они есть
	for (const auto& stage : Data::stages) {
		print_stage(stage.second);  // Печать каждой стадии
	}
}


std::wstring check_ending(const std::map<std::string, scu::Trait>& traits) {
	for (const auto& ending : scu::Data::endings) {
		const scu::Trait& trait = traits.at(ending.condition_trait_id);

		if (ending.is_condition_max && trait.value >= ending.condition_trait_value)
			return ending.description;
		if (!ending.is_condition_max && trait.value <= ending.condition_trait_value)
			return ending.description;
	}
	return L"";
}



int main() {
	SetConsoleOutputCP(CP_UTF8);
	setlocale(LC_ALL, "Russian");
	_setmode(_fileno(stdout), _O_U16TEXT);

	std::map<std::string, scu::Trait> traits = scu::Data::traits;
	std::wstring ending_description;




	//std::string stage_id = "S0";  // начальный этап
	//std::string event_id = "E0";  // первое событие (для теста)

	//	print_all_data();
	// Инициализация stage_id и event_id
	const auto& stage = scu::Data::stages.begin()->second;
	std::wcout << L"Stage name: " << stage.name << std::endl;

	// Выводим значения
	//std::wcout << L"stage_id: " << std::wstring(stage_id.begin(), stage_id.end()) << std::endl;

	//std::wcout << L"event_id: " << event_id.c_str() << std::endl;



	const scu::Stage& stage = scu::Data::stages.at(stage_id);
	const scu::Event& event = stage.events.at(event_id);

	print_stage(stage);

	// цикл до достижения одного из условий окончания
	//(ending_description = check_ending(traits)).empty()
	while (false) {
		system("cls");

		std::wcout << L"=== Этап: " << stage_id.c_str() << L" | Событие: " << event_id.c_str() << L" ===\n";
		print_traits(traits);
		print_event(event);

		std::wcout << L"\n(Заглушка: конец цикла, так как выбор не реализован)\n";
		break;  // сейчас просто один шаг
	}

	if (!ending_description.empty()) {
		std::wcout << L"\nКонец игры: " << ending_description << std::endl;
	}
	return 0;

}
